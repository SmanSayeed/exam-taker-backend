<div class="container direction-rtl">
    <div class="card mb-3">
      <div class="card-body">
        <div class="row g-3">
          <div class="col-4">
            <a href="https://app.loopsexam.xyz/exams-starting" target="_self">
                <div class="feature-card mx-auto text-center">
                    <div class="card mx-auto bg-gray">
                      {{-- <img src="img/demo-img/pwa.png" alt=""> --}}
                      <i class="fa-solid fa-box card-icon"></i>
                    </div>
                    <p class="mb-0">পরীক্ষা </p>
                  </div>
            </a>

          </div>
          <div class="col-4">
            <a href="https://forms.gle/8pMV8q7jwVargv8H9" target="_blank">
                <div class="feature-card mx-auto text-center">
                    <div class="card mx-auto bg-gray">
                      {{-- <img src="img/demo-img/js.png" alt=""> --}}
                      <i class="fa-solid fa-person-chalkboard card-icon"></i>
                    </div>
                    <p class="mb-0">মেন্টরিং</p>
                  </div>
            </a>

          </div>

          

          <div class="col-4">
            <a href="{{route('courses')}}" target="_self">
            <div class="feature-card mx-auto text-center">
              <div class="card mx-auto bg-gray">
                {{-- <img src="img/demo-img/js.png" alt="">
                 --}}
                 <i class="fa-solid fa-pen-fancy card-icon"></i>
              </div>
              <p class="mb-0">এক্সাম ব্যাচ</p>
            </div>
             </a>
          </div>
          
          <div class="col-4">
            <div class="feature-card mx-auto text-center">
              <div class="card mx-auto bg-gray">
                <img src="img/demo-img/bootstrap.png" alt="">
                <!--<i class="fa-solid fa-bolt card-icon card-icon-disable"></i>-->
            </div>
              <p class="mb-0">প্রশ্নব্যাংক</p>
            </div>
          </div>

          <div class="col-4">
            <div class="feature-card mx-auto text-center">
              <div class="card mx-auto bg-gray">
                {{-- <img src="img/demo-img/js.png" alt=""> --}}
                <i class="fa-regular fa-file-pdf card-icon card-icon-disable"></i>
              </div>
              <p class="mb-0">পিডিএফ </p>
            </div>
          </div>



          <div class="col-4">
            <div class="feature-card mx-auto text-center">
              <div class="card mx-auto bg-gray">
                {{-- <img src="img/demo-img/js.png" alt=""> --}}
                <i class="fa-solid fa-medal card-icon card-icon-disable"></i>
              </div>
              <p class="mb-0">রিভিউ</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
