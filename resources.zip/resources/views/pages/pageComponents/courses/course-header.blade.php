
<div class="container " style="margin-top: 70px;">
    <div class="card bg-primary mb-3 bg-img" style="background-image: url('img/core-img/1.png')">
      <div class="card-body direction-rtl p-4">
        <h2 class="text-white">All Courses</h2>
        <p class="mb-3 text-white">3+ Major Medical Exam Batch</p>
        <!--<a class="btn btn-warning" href="#">All courses <i class="bi bi-arrow-right"></i></a>-->
      </div>
    </div>
  </div>
