<div class="container">
    <div class="card card-bg-img bg-img bg-overlay mb-3" style="background-image: url('img/bg-img/3.jpg')">
      <div class="card-body direction-rtl p-4">
        <h2 class="text-white">12000+ questions</h2>
        <p class="mb-3 text-white">More than 750+ users</p>
        <!--<a class="btn btn-warning" href="elements.html">All categories <i class="bi bi-arrow-right"></i></a>-->
      </div>
    </div>
  </div>
