<?php
use App\Http\Controllers\Api\V1\Questions\SectionController;
use Illuminate\Support\Facades\Route;

Route::prefix('sections')->group(function () {
    Route::get('/', [SectionController::class, 'index']);
    Route::post('/', [SectionController::class, 'store']);
    Route::put('{section}', [SectionController::class, 'update']);
    Route::delete('{section}', [SectionController::class, 'destroy']);
    Route::patch('{section}/status/{status}', [SectionController::class, 'changeStatus']);
});
